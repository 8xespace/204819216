整合內容：
1. 從 masking.zip 提取頂極制作所片頭動畫（lib/intro）
2. 片頭 4 秒後自動進入 204819216 主選單
3. 主選單與遊戲主體已拆到 lib/game/game_setup_page.dart
4. lib/main.dart 改為直接進入片頭動畫

注意：
- LogoNaked 仍會讀取 assets/logo.png
- 如果你的專案沒有放這張圖，程式不會崩潰，會自動顯示 FlutterLogo 當作容錯
